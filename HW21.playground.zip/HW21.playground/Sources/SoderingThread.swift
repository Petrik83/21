import Foundation


public class SoderingThread: Thread {
    var safeStorage: SafeStorage
    var condition = NSCondition()
    var makerThread: MakerThread
    
    public init(safeStorage: SafeStorage, condition: NSCondition, makerThread: MakerThread) {
        self.safeStorage = safeStorage
        self.condition = condition
        self.makerThread = makerThread
    }
    

    public override func main() {
        while makerThread.isExecuting  {
            while (!available) {
                condition.wait()
            }
            while !soderingAvaible {
                condition.wait()
            }
            
            let removedChip = safeStorage.removeElement()
            let removedNumber = safeStorage.removeNumber()
            soderingAvaible = false
            SoderingThread.sleep(forTimeInterval: 0.001)
            print("I took chip No: \(removedNumber) for sodering")
            
            Thread.detachNewThread {
                removedChip.sodering()
                print("I sodered chip No: \(removedNumber)")
                soderingAvaible = true
                self.condition.signal()
            }

            if safeStorage.isStorageEmpty() {
                available = false
            }
        }
    }
}
