import Foundation

public class MakerThread: Thread {
    
    var safeStorage: SafeStorage
    var condition = NSCondition()
    let makerProcessDuration: Int
    let chipProductionFrequency: Int
    
    public init(safeStorage: SafeStorage, condition: NSCondition, makerProcessDuration: Int, chipProductionFrequency: Int) {
        self.safeStorage = safeStorage
        self.condition = condition
        self.makerProcessDuration = makerProcessDuration
        self.chipProductionFrequency = chipProductionFrequency
    }
    
    private var time = 0
    private var chipNumber = 1
    
    public override func main() {
        
        let timer = Timer(timeInterval: 1, repeats: true) { timer in
            if (self.time != 0) && (self.time % self.chipProductionFrequency == 0) && (self.time <= self.makerProcessDuration) {
                Thread.detachNewThread {
                    self.safeStorage.addElement(element: Chip.make(), chipNumber: self.chipNumber)
                    print("I made chip No: \(self.chipNumber)")
                    self.chipNumber += 1
                }
            } else {
                if (self.time > self.makerProcessDuration) && self.safeStorage.isStorageEmpty() {
                    timer.invalidate()
                }
            }
            print(self.time)
            self.time += 1
        }
        
        RunLoop.current.add(timer, forMode: .common)
        RunLoop.current.run()
    }
}
