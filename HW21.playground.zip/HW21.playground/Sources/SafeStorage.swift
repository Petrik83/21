import Foundation

public var available = false
public var soderingAvaible = true


public class SafeStorage {
    var condition = NSCondition()
    private var storage = [Chip]()
    private var chipNumberArray = [Int]()
    
    public init(condition: NSCondition) {
        self.condition = condition
        
    }
    
    public func addElement(element: Chip, chipNumber: Int)  {
        condition.lock()
        storage.insert(element, at: 0)
        chipNumberArray.insert(chipNumber, at: 0)
        available = true
        condition.signal()
        do {
            condition.unlock()
        }
    }
    
    public func removeElement() -> Chip {
        return storage.removeFirst()
    }
    
    public func removeNumber() -> Int {
        return chipNumberArray.removeFirst()
    }
    
    public func isStorageEmpty() -> Bool {
        return storage.isEmpty
    }
}
