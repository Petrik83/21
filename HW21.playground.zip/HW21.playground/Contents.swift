import Foundation

// для наглядности работы хранилища по принципу LIFO добавил в func sodering() +1 секунду к времени сборки чипа. иначе если мало создается больших чипов, то кажется что работает по FIFO

let condition = NSCondition()
let safeStorage = SafeStorage(condition: condition)

let makerProcessDuration = 20
let chipProductionFrequency = 2

let makerThread = MakerThread(safeStorage: safeStorage,
                              condition: condition,
                              makerProcessDuration: makerProcessDuration,
                              chipProductionFrequency: chipProductionFrequency)
let soderingThread = SoderingThread(safeStorage: safeStorage,
                                    condition: condition,
                                    makerThread: makerThread)

print("start")
makerThread.start()
soderingThread.start()

