import Foundation

let cond = NSCondition()
var available = false
var storage = [Chip]()

public struct Chip {
    public enum ChipType: UInt32 {
        case small = 1
        case medium
        case big
    }
    
    public let chipType: ChipType
    
    public static func make() -> Chip {
        guard let chipType = Chip.ChipType(rawValue: UInt32(arc4random_uniform(3) + 1)) else {
            fatalError("Incorrect random value")
        }
        return Chip(chipType: chipType)
    }
    
    public func sodering() {
        let soderingTime = chipType.rawValue
        sleep(UInt32(soderingTime))
        print("I sodered a chip")
    }
}

var makerThread = Thread {
    for _ in 1...10 {
        cond.lock()
        storage.insert(Chip.make(), at: 0)
        print("I made a chip")
        available = true
        cond.signal()
        cond.unlock()
        sleep(2)
    }
}

var soderingThread = Thread {
    for _ in 1...10 {
        while (!available) {
            cond.wait()
        }
        storage.removeFirst().sodering()
        if storage.count < 1 {
            available = false
        }
    }
}

makerThread.start()
soderingThread.start()
